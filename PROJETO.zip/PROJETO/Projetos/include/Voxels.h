#ifndef VOXELS_H
#define VOXELS_H


struct Voxels {
    float r,g,b; //Codigo RGB
    float a; // Transparencia
    bool show; //Visivel ou n�o
 };


#endif // VOXELS_H
