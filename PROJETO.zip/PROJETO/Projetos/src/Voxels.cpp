#include "Voxels.h"

Voxels::Voxels()
{
    //ctor
}

Voxels::~Voxels()
{
    //dtor
}
